﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Maestro
{

    [RequireComponent(typeof(MeshFilter))]
    public class MeshDeformer : MonoBehaviour
    {
        float uniformScale = 1f;

        public float force = 10f;
        public float forceOffset = 0.1f;

        public float damping = 5f;
        public float springForce = 20f;
        Vector3[] vertexVelocities;
        Mesh deformingMesh;
        Vector3[] originalVertices, displacedVertices;

        void Start()
        {
            deformingMesh = GetComponent<MeshFilter>().mesh;
            originalVertices = deformingMesh.vertices;
            displacedVertices = new Vector3[originalVertices.Length];
            for (int i = 0; i < originalVertices.Length; i++) {
                displacedVertices[i] = originalVertices[i];
            }

            vertexVelocities = new Vector3[originalVertices.Length];
        }

        public void AddDeformingForce(Vector3 point, float force)
        {
            point = transform.InverseTransformPoint(point);
            for (int i = 0; i < displacedVertices.Length; i++) {
                AddForceToVertex(i, point, force);
            }
            //Debug.DrawLine(Camera.main.transform.position, point);
        }

        void AddForceToVertex(int i, Vector3 point, float force)
        {
            Vector3 pointToVertex = displacedVertices[i] - point;
            pointToVertex *= uniformScale;
            //if (pointToVertex.magnitude < 150)
            //{
            float attenuatedForce = (1f + pointToVertex.sqrMagnitude) * force;
            float velocity = attenuatedForce * Time.deltaTime;
            vertexVelocities[i] += pointToVertex.normalized * velocity;
            //}
        }

        void Update()
        {
            uniformScale = transform.localScale.x;

            for (int i = 0; i < displacedVertices.Length; i++) {
                UpdateVertex(i);
            }
            deformingMesh.vertices = displacedVertices;
            deformingMesh.RecalculateNormals();
        }

        void UpdateVertex(int i)
        {
            Vector3 velocity = vertexVelocities[i];
            Vector3 displacement = displacedVertices[i] - originalVertices[i];
            displacement *= uniformScale;
            velocity -= displacement * springForce * Time.deltaTime;
            velocity *= 1f - damping * Time.deltaTime;
            vertexVelocities[i] = velocity;
            if (velocity.magnitude > 0.1f)
                displacedVertices[i] += velocity * (Time.deltaTime / uniformScale);
        }

        private void OnCollisionStay(Collision collision)
        {
            AddDeformingForce(collision.contacts[0].point + collision.contacts[0].normal * forceOffset, force);
        }
    }
}
